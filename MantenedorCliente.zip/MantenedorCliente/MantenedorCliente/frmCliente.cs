﻿using ClienteEntidad;
using ClienteLogica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MantenedorCliente
{
    public partial class frmCliente : Form
    {

        private List<entCliente> entClientes = null;
        private entCliente entClienteSelected = null;


        public frmCliente()
        {
            InitializeComponent();
        }

        private void frmCliente_Load(object sender, EventArgs e)
        {
            ListarClientes();
        }

        private void ListarClientes(List<entCliente> entClienteSeteado = null)
        {
            var response = logCliente.Instancia.ListarClientes();

            if (entClienteSeteado == null)
                entClientes = response;
            else
                entClientes = entClienteSeteado;
            dtgClientes.DataSource = null;
            dtgClientes.DataSource = entClientes;
        }

        private void dtgClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowindex = dtgClientes.CurrentRow.Index;
            var value = dtgClientes.CurrentRow.Cells[0].Value;
            entClienteSelected = entClientes.Find(m => m.ID == Convert.ToInt32(value));
            ShowValuesSelected(entClienteSelected);
        }


        private void ShowValuesSelected(entCliente entCliente)
        {
            txtNombre.Text = entCliente.Nombre;
            txtApellidoPaterno.Text = entCliente.ApellidoPaterno;
            txtApellidoMaterno.Text = entCliente.ApellidoMaterno;
            txtDocumento.Text = entCliente.Documento;
            dtpFechaNac.Value = entCliente.FechaNac;
            txtCorreoElectronico.Text = entCliente.CorreoElectronico;
            txtTelefono.Text = entCliente.Telefono;
            txtCelular.Text = entCliente.Celular;
            chkEstado.Checked = entCliente.Estado;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            entClienteSelected = null;

            txtNombre.ReadOnly = false;
            txtApellidoPaterno.ReadOnly = false;
            txtApellidoMaterno.ReadOnly = false;
            txtDocumento.ReadOnly = false;
            dtpFechaNac.Enabled = true;
            txtCorreoElectronico.ReadOnly = false;
            txtTelefono.ReadOnly = false;
            txtCelular.ReadOnly = false;

            txtNombre.Clear();
            txtApellidoPaterno.Clear();
            txtApellidoMaterno.Clear();
            txtDocumento.Clear();
            txtCorreoElectronico.Clear();
            txtTelefono.Clear();
            txtCelular.Clear();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            var estado = txtNombre.ReadOnly;
            txtNombre.ReadOnly = !estado;
            txtApellidoPaterno.ReadOnly = !estado;
            txtApellidoMaterno.ReadOnly = !estado;
            txtDocumento.ReadOnly = !estado;
            txtCorreoElectronico.ReadOnly = !estado;
            txtTelefono.ReadOnly = !estado;
            txtCelular.ReadOnly = !estado;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (entClienteSelected != null)
                logCliente.Instancia.DeshabilitaCliente(entClienteSelected.ID);

            ListarClientes();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (entClienteSelected == null)
            {
                entCliente cliente = new entCliente();
                cliente.Nombre = txtNombre.Text;
                cliente.ApellidoPaterno = txtApellidoPaterno.Text;
                cliente.ApellidoMaterno = txtApellidoMaterno.Text;
                cliente.Documento = txtDocumento.Text;
                cliente.CorreoElectronico = txtCorreoElectronico.Text;
                cliente.Telefono = txtTelefono.Text;
                cliente.Celular = txtCelular.Text;
                cliente.Estado = chkEstado.Checked;
                cliente.FechaNac = dtpFechaNac.Value;
                logCliente.Instancia.InsertaCliente(cliente);
            }
            else
            {
                entClienteSelected.Nombre = txtNombre.Text;
                entClienteSelected.ApellidoPaterno = txtApellidoPaterno.Text;
                entClienteSelected.ApellidoMaterno = txtApellidoMaterno.Text;
                entClienteSelected.Documento = txtDocumento.Text;
                entClienteSelected.CorreoElectronico = txtCorreoElectronico.Text;
                entClienteSelected.Telefono = txtTelefono.Text;
                entClienteSelected.Celular = txtCelular.Text;
                entClienteSelected.Estado = chkEstado.Checked;
                entClienteSelected.FechaNac = dtpFechaNac.Value;
                logCliente.Instancia.EditaCliente(entClienteSelected);
            }

            ListarClientes();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtBusqueda_TextChanged(object sender, EventArgs e)
        {
            if (txtBusqueda.TextLength > 0)
            {
                if (entClientes != null)
                {
                    var list = entClientes.FindAll(m => m.Nombre.ToLower().Contains(txtBusqueda.Text.ToLower()));
                    ListarClientes(list);
                }
            }
            else
                ListarClientes();
        }
    }
}
