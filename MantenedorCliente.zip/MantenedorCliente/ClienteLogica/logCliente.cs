﻿using ClienteDatos;
using ClienteEntidad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClienteLogica
{
    public class logCliente
    {
        private static readonly logCliente _instancia = new logCliente();
        public static logCliente Instancia
        {
            get { return logCliente._instancia; }
        }

        public List<entCliente> ListarClientes()
        {
            return datCliente.Instancia.ListarCliente();
        }
        public void InsertaCliente(entCliente cliente)
        {
            try
            {
                datCliente.Instancia.InsertarCliente(cliente);
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        public void EditaCliente(entCliente cliente)
        {
            try
            {
                datCliente.Instancia.EditarCliente(cliente);
            }
            catch (Exception e)
            {
                throw e;

            }

        }
        public void DeshabilitaCliente(int idCliente)
        {
            try
            {
                datCliente.Instancia.DeshabilitaCliente(idCliente);
            }
            catch (Exception e)
            {
                throw e;

            }
        }
    }
}
